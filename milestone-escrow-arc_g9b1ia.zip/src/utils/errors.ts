export function parseOnchainError(error: unknown): string {
  const msg = (error as { message?: string })?.message?.toLowerCase() ?? '';

  if (msg.includes('user rejected') || (error as { code?: number })?.code === 4001) {
    return 'Transaction cancelled.';
  }
  if (msg.includes('notclient')) return 'Only the client can perform this action.';
  if (msg.includes('milestonenot pending') || msg.includes('milestonenotpending')) {
    return 'This milestone is not in a pending state.';
  }
  if (msg.includes('milestonenotapproved')) return 'Milestone must be approved before release.';
  if (msg.includes('milestonenotrefundable')) return 'Milestone cannot be refunded in its current state.';
  if (msg.includes('deadlinenotpassed')) return 'The milestone deadline has not passed yet.';
  if (msg.includes('invaliddeadline')) return 'Deadline must be in the future.';
  if (msg.includes('invalidamount')) return 'Milestone amount must be greater than zero.';
  if (msg.includes('invalidfreelancer')) return 'Invalid freelancer address.';
  if (msg.includes('transferfailed')) return 'USDC transfer failed — check your allowance and balance.';
  if (msg.includes('insufficient funds') || msg.includes('exceeds balance')) {
    return 'Insufficient USDC balance.';
  }
  if (msg.includes('reverted')) {
    const match = msg.match(/reason="([^"]+)"/);
    return match ? `Transaction failed: ${match[1]}` : 'Transaction reverted. Check your inputs.';
  }
  if (msg.includes('network') || msg.includes('timeout')) {
    return 'Network error. Please check your connection and try again.';
  }
  return 'Something went wrong. Please try again.';
}

export const formatAddress = (addr: string) =>
  `${addr.slice(0, 6)}...${addr.slice(-4)}`;
