/**
 * FreelanceEscrow contract ABI and bytecode.
 * Generated from /home/user/app/contracts/out/FreelanceEscrow.sol/FreelanceEscrow.json
 * Import and use this to deploy new escrow instances from the user's wallet.
 */

export const FREELANCE_ESCROW_ABI = [
  {
    type: 'constructor',
    inputs: [
      { name: '_freelancer', type: 'address', internalType: 'address' },
      { name: '_usdcToken', type: 'address', internalType: 'address' },
      { name: '_amounts', type: 'uint256[3]', internalType: 'uint256[3]' },
      { name: '_deadlines', type: 'uint256[3]', internalType: 'uint256[3]' },
    ],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'approveMilestone',
    inputs: [{ name: 'milestoneIndex', type: 'uint256', internalType: 'uint256' }],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'releaseMilestone',
    inputs: [{ name: 'milestoneIndex', type: 'uint256', internalType: 'uint256' }],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'refundMilestone',
    inputs: [{ name: 'milestoneIndex', type: 'uint256', internalType: 'uint256' }],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'getMilestone',
    inputs: [{ name: 'index', type: 'uint256', internalType: 'uint256' }],
    outputs: [
      { name: 'amount', type: 'uint256', internalType: 'uint256' },
      { name: 'status', type: 'uint8', internalType: 'uint8' },
      { name: 'deadline', type: 'uint256', internalType: 'uint256' },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'getContractBalance',
    inputs: [],
    outputs: [{ name: '', type: 'uint256', internalType: 'uint256' }],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'getEscrowInfo',
    inputs: [],
    outputs: [
      { name: 'escrowClient', type: 'address', internalType: 'address' },
      { name: 'escrowFreelancer', type: 'address', internalType: 'address' },
      { name: 'usdc', type: 'address', internalType: 'address' },
      { name: 'funded', type: 'uint256', internalType: 'uint256' },
    ],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'client',
    inputs: [],
    outputs: [{ name: '', type: 'address', internalType: 'address' }],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'freelancer',
    inputs: [],
    outputs: [{ name: '', type: 'address', internalType: 'address' }],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'totalFunded',
    inputs: [],
    outputs: [{ name: '', type: 'uint256', internalType: 'uint256' }],
    stateMutability: 'view',
  },
  {
    type: 'event',
    name: 'MilestoneApproved',
    inputs: [{ name: 'milestoneIndex', type: 'uint256', indexed: true, internalType: 'uint256' }],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'MilestoneReleased',
    inputs: [
      { name: 'milestoneIndex', type: 'uint256', indexed: true, internalType: 'uint256' },
      { name: 'amount', type: 'uint256', indexed: false, internalType: 'uint256' },
    ],
    anonymous: false,
  },
  {
    type: 'event',
    name: 'MilestoneRefunded',
    inputs: [
      { name: 'milestoneIndex', type: 'uint256', indexed: true, internalType: 'uint256' },
      { name: 'amount', type: 'uint256', indexed: false, internalType: 'uint256' },
    ],
    anonymous: false,
  },
  { type: 'error', name: 'NotClient', inputs: [] },
  { type: 'error', name: 'InvalidFreelancer', inputs: [] },
  { type: 'error', name: 'InvalidAmount', inputs: [] },
  { type: 'error', name: 'InvalidDeadline', inputs: [] },
  { type: 'error', name: 'InvalidMilestoneIndex', inputs: [] },
  { type: 'error', name: 'MilestoneNotPending', inputs: [] },
  { type: 'error', name: 'MilestoneNotApproved', inputs: [] },
  { type: 'error', name: 'MilestoneNotRefundable', inputs: [] },
  { type: 'error', name: 'DeadlineNotPassed', inputs: [] },
  { type: 'error', name: 'TransferFailed', inputs: [] },
] as const;

// MilestoneStatus enum values matching the contract
export enum MilestoneStatus {
  Pending = 0,
  Approved = 1,
  Released = 2,
  Refunded = 3,
}

export const MILESTONE_STATUS_LABEL: Record<number, string> = {
  [MilestoneStatus.Pending]: 'Pending',
  [MilestoneStatus.Approved]: 'Approved',
  [MilestoneStatus.Released]: 'Released',
  [MilestoneStatus.Refunded]: 'Refunded',
};
