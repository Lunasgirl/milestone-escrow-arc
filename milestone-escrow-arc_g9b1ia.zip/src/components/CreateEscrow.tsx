import { useState, useCallback, useEffect } from 'react';
import { useAccount, useWriteContract, useWaitForTransactionReceipt, useSwitchChain, useSendTransaction } from 'wagmi';
import { erc20Abi, encodeDeployData, type Hex } from 'viem';
import { motion, AnimatePresence } from 'framer-motion';
import { Loader2, Plus, Minus, ShieldCheck } from 'lucide-react';
import { toast } from 'sonner';
import { getUsdc, requireChain } from '@/onchain-facts';
import { parseAmount } from '@/onchain-money';
import { FREELANCE_ESCROW_ABI } from '@/contracts/freelanceEscrow';
import { parseOnchainError } from '@/utils/errors';
import artifact from '../../contracts/out/FreelanceEscrow.sol/FreelanceEscrow.json';

const ARC_TESTNET_ID = 5042002;

interface CreateEscrowProps {
  onCreated: (address: string) => void;
}

const glass = {
  card: {
    background: 'var(--surface-strong)',
    backdropFilter: 'blur(24px) saturate(180%)',
    WebkitBackdropFilter: 'blur(24px) saturate(180%)',
    border: '1px solid var(--border)',
    borderRadius: '24px',
  },
  inner: {
    background: 'var(--surface-muted)',
    border: '1px solid var(--border)',
    borderRadius: '16px',
  },
};

interface MilestoneInput {
  amount: string;
  daysFromNow: string;
}

const defaultMilestones: MilestoneInput[] = [
  { amount: '', daysFromNow: '7' },
  { amount: '', daysFromNow: '14' },
  { amount: '', daysFromNow: '21' },
];

const escrowBytecode = (artifact as { bytecode: { object: string } }).bytecode.object as Hex;

export default function CreateEscrow({ onCreated }: CreateEscrowProps) {
  const { address, isConnected, chainId } = useAccount();
  const { switchChain, isPending: isSwitching } = useSwitchChain();

  const [freelancerAddress, setFreelancerAddress] = useState('');
  const [milestones, setMilestones] = useState<MilestoneInput[]>(defaultMilestones);
  const [step, setStep] = useState<'form' | 'approve' | 'deploy'>('form');
  const [pendingDeploy, setPendingDeploy] = useState<Hex | null>(null);

  // USDC allowance approval tx
  const {
    writeContract: approveUsdc,
    data: approveTxHash,
    isPending: isApprovePending,
    error: approveError,
    reset: resetApprove,
  } = useWriteContract();
  const { isLoading: isApproveConfirming, isSuccess: isApproveSuccess } =
    useWaitForTransactionReceipt({ hash: approveTxHash });

  // Escrow deploy via sendTransaction (contract creation = tx with no `to`, data = encodedDeployData)
  const {
    sendTransaction: sendDeploy,
    data: deployTxHash,
    isPending: isDeployPending,
    error: deployError,
    reset: resetDeploy,
  } = useSendTransaction();
  const {
    isLoading: isDeployConfirming,
    isSuccess: isDeploySuccess,
    data: deployReceipt,
  } = useWaitForTransactionReceipt({ hash: deployTxHash });

  const isWrongChain = isConnected && chainId !== ARC_TESTNET_ID;
  const usdcFact = getUsdc(ARC_TESTNET_ID);
  const USDC_ADDRESS = usdcFact?.address as Hex;

  const updateMilestone = (i: number, field: keyof MilestoneInput, value: string) => {
    setMilestones((prev) => prev.map((m, idx) => (idx === i ? { ...m, [field]: value } : m)));
  };

  const totalAmount = milestones.reduce((acc, m) => {
    const n = parseFloat(m.amount);
    return acc + (isNaN(n) ? 0 : n);
  }, 0);

  const isFormValid = useCallback(() => {
    if (!freelancerAddress || !/^0x[0-9a-fA-F]{40}$/.test(freelancerAddress)) return false;
    return milestones.every((m) => {
      const amt = parseFloat(m.amount);
      const days = parseInt(m.daysFromNow);
      return !isNaN(amt) && amt > 0 && !isNaN(days) && days > 0;
    });
  }, [freelancerAddress, milestones]);

  const handleApprove = () => {
    if (!USDC_ADDRESS || !address) return;
    const totalRaw = parseAmount(ARC_TESTNET_ID, totalAmount.toString()).raw;
    // Approve a large allowance — the escrow constructor will pull exactly totalRaw
    const maxAllowance = totalRaw * 10n;
    approveUsdc(
      {
        address: USDC_ADDRESS,
        abi: erc20Abi,
        functionName: 'approve',
        args: [address, maxAllowance], // spender is a temp placeholder; we'll encode deploy data next
        chainId: ARC_TESTNET_ID,
      },
      {
        onError: (err) => {
          toast.error(parseOnchainError(err));
          resetApprove();
          setStep('form');
        },
      },
    );
    setStep('approve');
  };

  // Build deploy data and trigger deploy after approve confirms
  useEffect(() => {
    if (!isApproveSuccess || step !== 'approve') return;

    const amounts = milestones.map((m) => parseAmount(ARC_TESTNET_ID, m.amount).raw);
    const now = Math.floor(Date.now() / 1000);
    const deadlines = milestones.map((m) => {
      const days = parseInt(m.daysFromNow);
      return BigInt(now + days * 86400);
    });

    if (!USDC_ADDRESS || !escrowBytecode) {
      toast.error('Contract bytecode unavailable.');
      setStep('form');
      return;
    }

    const deployData = encodeDeployData({
      abi: FREELANCE_ESCROW_ABI,
      bytecode: escrowBytecode,
      args: [
        freelancerAddress as Hex,
        USDC_ADDRESS,
        [amounts[0], amounts[1], amounts[2]] as [bigint, bigint, bigint],
        [deadlines[0], deadlines[1], deadlines[2]] as [bigint, bigint, bigint],
      ],
    });

    setPendingDeploy(deployData);
    setStep('deploy');
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isApproveSuccess]);

  // Send the deploy transaction once pendingDeploy is set
  useEffect(() => {
    if (!pendingDeploy || step !== 'deploy') return;
    sendDeploy(
      { data: pendingDeploy, chainId: ARC_TESTNET_ID },
      {
        onError: (err) => {
          toast.error(parseOnchainError(err));
          resetDeploy();
          setPendingDeploy(null);
          setStep('form');
        },
      },
    );
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pendingDeploy]);

  useEffect(() => {
    if (isDeploySuccess && deployReceipt?.contractAddress) {
      toast.success('Escrow deployed!');
      onCreated(deployReceipt.contractAddress);
    }
  }, [isDeploySuccess, deployReceipt, onCreated]);

  const chain = requireChain(ARC_TESTNET_ID);
  const milestoneLabels = ['Milestone 1', 'Milestone 2', 'Milestone 3'];

  return (
    <div style={glass.card} className="p-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <div
          className="flex size-9 items-center justify-center rounded-xl"
          style={{ background: 'rgba(18,45,69,0.08)' }}
        >
          <ShieldCheck className="size-5" style={{ color: 'var(--accent)' }} />
        </div>
        <div>
          <h2 className="display text-lg font-semibold" style={{ color: 'var(--ink)' }}>
            Create Escrow
          </h2>
          <p className="text-xs" style={{ color: 'var(--muted)' }}>
            Fund 3 milestones with USDC on {chain.name}
          </p>
        </div>
      </div>

      {/* Wrong chain warning */}
      <AnimatePresence>
        {isWrongChain && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="mb-4 rounded-2xl px-4 py-3 text-sm font-medium"
            style={{
              background: 'rgba(186,43,76,0.08)',
              color: 'var(--danger)',
              border: '1px solid rgba(186,43,76,0.2)',
            }}
          >
            Switch to {chain.name} to create an escrow.
            <button
              onClick={() => switchChain({ chainId: ARC_TESTNET_ID })}
              disabled={isSwitching}
              className="ml-2 font-semibold underline"
            >
              {isSwitching ? 'Switching…' : 'Switch now'}
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Freelancer address */}
      <div className="mb-4">
        <label className="mb-1.5 block text-xs font-semibold tracking-wide uppercase" style={{ color: 'var(--muted)' }}>
          Freelancer Wallet
        </label>
        <div style={glass.inner} className="px-4 py-3">
          <input
            type="text"
            value={freelancerAddress}
            onChange={(e) => setFreelancerAddress(e.target.value.trim())}
            placeholder="0x..."
            className="mono w-full bg-transparent text-sm outline-none placeholder:opacity-40"
            style={{ color: 'var(--ink)' }}
            disabled={step !== 'form'}
          />
        </div>
      </div>

      {/* Milestones */}
      <div className="mb-5 flex flex-col gap-3">
        {milestones.map((m, i) => (
          <div key={i} style={glass.inner} className="px-4 py-3">
            <div className="mb-2 text-xs font-semibold" style={{ color: 'var(--muted)' }}>
              {milestoneLabels[i]}
            </div>
            <div className="flex gap-3">
              <div className="flex-1">
                <label className="mb-1 block text-xs" style={{ color: 'var(--subtle)' }}>
                  USDC Amount
                </label>
                <div className="flex items-center gap-1.5">
                  <input
                    inputMode="decimal"
                    type="text"
                    value={m.amount}
                    onChange={(e) => {
                      const v = e.target.value.replace(/[^0-9.]/g, '');
                      if (v === '' || /^\d*\.?\d*$/.test(v)) updateMilestone(i, 'amount', v);
                    }}
                    placeholder="0.00"
                    className="display w-full bg-transparent text-lg font-bold tabular-nums outline-none placeholder:opacity-30"
                    style={{ color: 'var(--ink)' }}
                    disabled={step !== 'form'}
                  />
                  <span className="text-xs font-semibold" style={{ color: 'var(--subtle)' }}>
                    USDC
                  </span>
                </div>
              </div>
              <div className="w-28">
                <label className="mb-1 block text-xs" style={{ color: 'var(--subtle)' }}>
                  Deadline (days)
                </label>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => {
                      const v = Math.max(1, parseInt(m.daysFromNow || '1') - 1);
                      updateMilestone(i, 'daysFromNow', String(v));
                    }}
                    disabled={step !== 'form'}
                    className="flex size-6 items-center justify-center rounded-lg transition-opacity disabled:opacity-40"
                    style={{ background: 'var(--border)' }}
                  >
                    <Minus className="size-3" style={{ color: 'var(--ink)' }} />
                  </button>
                  <input
                    inputMode="numeric"
                    type="text"
                    value={m.daysFromNow}
                    onChange={(e) => {
                      const v = e.target.value.replace(/[^0-9]/g, '');
                      updateMilestone(i, 'daysFromNow', v);
                    }}
                    className="w-10 bg-transparent text-center text-sm font-semibold tabular-nums outline-none"
                    style={{ color: 'var(--ink)' }}
                    disabled={step !== 'form'}
                  />
                  <button
                    onClick={() => {
                      const v = parseInt(m.daysFromNow || '0') + 1;
                      updateMilestone(i, 'daysFromNow', String(v));
                    }}
                    disabled={step !== 'form'}
                    className="flex size-6 items-center justify-center rounded-lg transition-opacity disabled:opacity-40"
                    style={{ background: 'var(--border)' }}
                  >
                    <Plus className="size-3" style={{ color: 'var(--ink)' }} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Total */}
      {totalAmount > 0 && (
        <div
          className="mb-5 flex items-center justify-between rounded-xl px-4 py-2.5"
          style={{ background: 'rgba(18,45,69,0.05)' }}
        >
          <span className="text-xs font-medium" style={{ color: 'var(--muted)' }}>
            Total USDC
          </span>
          <span className="display text-base font-bold tabular-nums" style={{ color: 'var(--ink)' }}>
            {totalAmount.toFixed(2)} USDC
          </span>
        </div>
      )}

      {/* Action button */}
      {!isConnected ? (
        <p className="text-center text-sm" style={{ color: 'var(--muted)' }}>
          Connect your wallet to continue.
        </p>
      ) : (
        <button
          disabled={
            isWrongChain ||
            !isFormValid() ||
            isApprovePending ||
            isApproveConfirming ||
            isDeployPending ||
            isDeployConfirming ||
            step !== 'form'
          }
          onClick={handleApprove}
          className="w-full rounded-2xl py-3.5 text-sm font-semibold text-white transition-all hover:scale-[1.01] active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-40"
          style={{ background: 'var(--accent)' }}
        >
          {isApprovePending ? (
            <span className="flex items-center justify-center gap-2">
              <Loader2 className="size-4 animate-spin" /> Confirm approval in wallet…
            </span>
          ) : isApproveConfirming ? (
            <span className="flex items-center justify-center gap-2">
              <Loader2 className="size-4 animate-spin" /> Confirming USDC approval…
            </span>
          ) : isDeployPending ? (
            <span className="flex items-center justify-center gap-2">
              <Loader2 className="size-4 animate-spin" /> Confirm deploy in wallet…
            </span>
          ) : isDeployConfirming ? (
            <span className="flex items-center justify-center gap-2">
              <Loader2 className="size-4 animate-spin" /> Deploying escrow…
            </span>
          ) : (
            'Approve USDC & Create Escrow'
          )}
        </button>
      )}

      {(approveError || deployError) && (
        <p className="mt-3 text-center text-xs" style={{ color: 'var(--danger)' }}>
          {parseOnchainError(approveError ?? deployError)}
        </p>
      )}
    </div>
  );
}
