import { Check, Clock, RefreshCw, DollarSign } from 'lucide-react';
import { MilestoneStatus } from '@/contracts/freelanceEscrow';

interface MilestoneBadgeProps {
  status: number;
}

const config: Record<
  number,
  { label: string; bg: string; color: string; Icon: typeof Check }
> = {
  [MilestoneStatus.Pending]: {
    label: 'Pending',
    bg: 'rgba(107, 101, 128, 0.1)',
    color: 'var(--muted)',
    Icon: Clock,
  },
  [MilestoneStatus.Approved]: {
    label: 'Approved',
    bg: 'rgba(16, 97, 166, 0.1)',
    color: '#1061a6',
    Icon: Check,
  },
  [MilestoneStatus.Released]: {
    label: 'Released',
    bg: 'rgba(26, 128, 71, 0.1)',
    color: 'var(--success)',
    Icon: DollarSign,
  },
  [MilestoneStatus.Refunded]: {
    label: 'Refunded',
    bg: 'rgba(186, 43, 76, 0.1)',
    color: 'var(--danger)',
    Icon: RefreshCw,
  },
};

export default function MilestoneBadge({ status }: MilestoneBadgeProps) {
  const cfg = config[status] ?? config[MilestoneStatus.Pending];
  const { label, bg, color, Icon } = cfg;

  return (
    <span
      className="inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold"
      style={{ background: bg, color }}
    >
      <Icon className="size-3" />
      {label}
    </span>
  );
}
