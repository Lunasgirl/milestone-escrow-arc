import { useState } from 'react';
import { type Hex } from 'viem';
import { Search } from 'lucide-react';

const glass = {
  card: {
    background: 'var(--surface-strong)',
    backdropFilter: 'blur(24px) saturate(180%)',
    WebkitBackdropFilter: 'blur(24px) saturate(180%)',
    border: '1px solid var(--border)',
    borderRadius: '24px',
  },
  inner: {
    background: 'var(--surface-muted)',
    border: '1px solid var(--border)',
    borderRadius: '16px',
  },
};

interface LoadEscrowProps {
  onLoad: (address: Hex) => void;
}

export default function LoadEscrow({ onLoad }: LoadEscrowProps) {
  const [value, setValue] = useState('');
  const isValid = /^0x[0-9a-fA-F]{40}$/.test(value.trim());

  return (
    <div style={glass.card} className="p-6">
      <p className="mb-3 text-sm font-medium" style={{ color: 'var(--muted)' }}>
        Already have an escrow? Load it by address.
      </p>
      <div className="flex gap-2">
        <div style={glass.inner} className="flex flex-1 items-center gap-2 px-3 py-2.5">
          <Search className="size-4 shrink-0" style={{ color: 'var(--subtle)' }} />
          <input
            type="text"
            value={value}
            onChange={(e) => setValue(e.target.value.trim())}
            placeholder="0x contract address…"
            className="mono w-full bg-transparent text-sm outline-none placeholder:opacity-40"
            style={{ color: 'var(--ink)' }}
          />
        </div>
        <button
          disabled={!isValid}
          onClick={() => isValid && onLoad(value as Hex)}
          className="rounded-2xl px-4 py-2.5 text-sm font-semibold text-white transition-all hover:scale-[1.01] active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-40"
          style={{ background: 'var(--accent)' }}
        >
          Load
        </button>
      </div>
    </div>
  );
}
