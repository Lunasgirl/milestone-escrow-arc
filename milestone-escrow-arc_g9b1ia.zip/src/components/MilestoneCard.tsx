import { useWriteContract, useWaitForTransactionReceipt } from 'wagmi';
import { type Hex } from 'viem';
import { motion } from 'framer-motion';
import { Loader2, CheckCircle, Send, Undo2, ExternalLink } from 'lucide-react';
import { toast } from 'sonner';
import { Amount, usdcDecimalsFor } from '@/onchain-money';
import { buildTxExplorerUrl } from '@/onchain-facts';
import { FREELANCE_ESCROW_ABI, MilestoneStatus } from '@/contracts/freelanceEscrow';
import MilestoneBadge from './MilestoneBadge';
import { parseOnchainError } from '@/utils/errors';

const ARC_TESTNET_ID = 5042002;

interface MilestoneCardProps {
  index: number;
  amount: bigint;
  status: number;
  deadline: bigint;
  escrowAddress: Hex;
  isClient: boolean;
  onAction: () => void;
}

const glass = {
  card: {
    background: 'var(--surface-strong)',
    backdropFilter: 'blur(16px) saturate(160%)',
    WebkitBackdropFilter: 'blur(16px) saturate(160%)',
    border: '1px solid var(--border)',
    borderRadius: '20px',
  },
};

const MILESTONE_LABELS = ['Milestone 1', 'Milestone 2', 'Milestone 3'];
const MILESTONE_DESCS = ['Initial deliverable', 'Core development', 'Final delivery & review'];

function formatDeadline(ts: bigint): string {
  const d = new Date(Number(ts) * 1000);
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function isDeadlinePassed(ts: bigint): boolean {
  return Date.now() / 1000 > Number(ts);
}

export default function MilestoneCard({
  index,
  amount,
  status,
  deadline,
  escrowAddress,
  isClient,
  onAction,
}: MilestoneCardProps) {
  const decimals = usdcDecimalsFor(ARC_TESTNET_ID);
  const formatted = Amount.fromRaw(amount, decimals).toFixed(2);
  const deadlinePassed = isDeadlinePassed(deadline);

  // Approve
  const {
    writeContract: doApprove,
    data: approveTxHash,
    isPending: isApprovePending,
  } = useWriteContract();
  const { isLoading: isApproveConfirming } = useWaitForTransactionReceipt({ hash: approveTxHash });

  // Release
  const {
    writeContract: doRelease,
    data: releaseTxHash,
    isPending: isReleasePending,
  } = useWriteContract();
  const { isLoading: isReleaseConfirming } = useWaitForTransactionReceipt({ hash: releaseTxHash });

  // Refund
  const {
    writeContract: doRefund,
    data: refundTxHash,
    isPending: isRefundPending,
  } = useWriteContract();
  const { isLoading: isRefundConfirming } = useWaitForTransactionReceipt({ hash: refundTxHash });

  const anyPending =
    isApprovePending ||
    isApproveConfirming ||
    isReleasePending ||
    isReleaseConfirming ||
    isRefundPending ||
    isRefundConfirming;

  const handleApprove = () => {
    doApprove(
      {
        address: escrowAddress,
        abi: FREELANCE_ESCROW_ABI,
        functionName: 'approveMilestone',
        args: [BigInt(index)],
        chainId: ARC_TESTNET_ID,
      },
      {
        onSuccess: () => { toast.success(`Milestone ${index + 1} approved`); onAction(); },
        onError: (err) => toast.error(parseOnchainError(err)),
      },
    );
  };

  const handleRelease = () => {
    doRelease(
      {
        address: escrowAddress,
        abi: FREELANCE_ESCROW_ABI,
        functionName: 'releaseMilestone',
        args: [BigInt(index)],
        chainId: ARC_TESTNET_ID,
      },
      {
        onSuccess: () => { toast.success(`Milestone ${index + 1} funds released!`); onAction(); },
        onError: (err) => toast.error(parseOnchainError(err)),
      },
    );
  };

  const handleRefund = () => {
    doRefund(
      {
        address: escrowAddress,
        abi: FREELANCE_ESCROW_ABI,
        functionName: 'refundMilestone',
        args: [BigInt(index)],
        chainId: ARC_TESTNET_ID,
      },
      {
        onSuccess: () => { toast.success(`Milestone ${index + 1} refunded`); onAction(); },
        onError: (err) => toast.error(parseOnchainError(err)),
      },
    );
  };

  const s = status as MilestoneStatus;
  const canApprove = isClient && s === MilestoneStatus.Pending;
  const canRelease = isClient && s === MilestoneStatus.Approved;
  const canRefund =
    isClient &&
    (s === MilestoneStatus.Pending || s === MilestoneStatus.Approved) &&
    deadlinePassed;

  const latestTxHash = releaseTxHash ?? refundTxHash ?? approveTxHash;

  return (
    <motion.div
      style={glass.card}
      className="p-4"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.06 }}
    >
      {/* Top row */}
      <div className="flex items-start justify-between mb-3">
        <div>
          <div className="text-xs font-semibold tracking-wide uppercase" style={{ color: 'var(--muted)' }}>
            {MILESTONE_LABELS[index]}
          </div>
          <div className="mt-0.5 text-xs" style={{ color: 'var(--subtle)' }}>
            {MILESTONE_DESCS[index]}
          </div>
        </div>
        <MilestoneBadge status={status} />
      </div>

      {/* Amount */}
      <div className="flex items-baseline gap-1 mb-3">
        <span className="display text-2xl font-bold tabular-nums" style={{ color: 'var(--ink)' }}>
          {formatted}
        </span>
        <span className="text-sm font-medium" style={{ color: 'var(--subtle)' }}>
          USDC
        </span>
      </div>

      {/* Deadline */}
      <div
        className="mb-4 flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs"
        style={{
          background: deadlinePassed
            ? 'rgba(186,43,76,0.07)'
            : 'rgba(18,45,69,0.05)',
          color: deadlinePassed ? 'var(--danger)' : 'var(--muted)',
        }}
      >
        <span className="font-medium">
          {deadlinePassed ? 'Deadline passed' : 'Due'}
        </span>
        <span>{formatDeadline(deadline)}</span>
      </div>

      {/* Action buttons — only shown to client */}
      {isClient && s !== MilestoneStatus.Released && s !== MilestoneStatus.Refunded && (
        <div className="flex flex-wrap gap-2">
          {canApprove && (
            <button
              disabled={anyPending}
              onClick={handleApprove}
              className="flex flex-1 items-center justify-center gap-1.5 rounded-xl py-2.5 text-xs font-semibold text-white transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-40"
              style={{ background: '#1061a6' }}
            >
              {isApprovePending || isApproveConfirming ? (
                <Loader2 className="size-3.5 animate-spin" />
              ) : (
                <CheckCircle className="size-3.5" />
              )}
              Approve
            </button>
          )}
          {canRelease && (
            <button
              disabled={anyPending}
              onClick={handleRelease}
              className="flex flex-1 items-center justify-center gap-1.5 rounded-xl py-2.5 text-xs font-semibold text-white transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-40"
              style={{ background: 'var(--success)' }}
            >
              {isReleasePending || isReleaseConfirming ? (
                <Loader2 className="size-3.5 animate-spin" />
              ) : (
                <Send className="size-3.5" />
              )}
              Release USDC
            </button>
          )}
          {canRefund && (
            <button
              disabled={anyPending}
              onClick={handleRefund}
              className="flex flex-1 items-center justify-center gap-1.5 rounded-xl py-2.5 text-xs font-semibold transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-40"
              style={{
                background: 'rgba(186,43,76,0.1)',
                color: 'var(--danger)',
                border: '1px solid rgba(186,43,76,0.2)',
              }}
            >
              {isRefundPending || isRefundConfirming ? (
                <Loader2 className="size-3.5 animate-spin" />
              ) : (
                <Undo2 className="size-3.5" />
              )}
              Refund
            </button>
          )}
        </div>
      )}

      {/* Explorer link for completed milestones */}
      {latestTxHash && (
        <a
          href={buildTxExplorerUrl(ARC_TESTNET_ID, latestTxHash)}
          target="_blank"
          rel="noreferrer"
          className="mt-3 flex items-center gap-1 text-xs transition-opacity hover:opacity-70"
          style={{ color: 'var(--muted)' }}
        >
          View on ArcScan <ExternalLink className="size-3" />
        </a>
      )}
    </motion.div>
  );
}
