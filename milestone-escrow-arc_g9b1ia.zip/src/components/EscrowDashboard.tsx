import { useReadContract, useAccount } from 'wagmi';
import { type Hex } from 'viem';
import { motion } from 'framer-motion';
import { Wallet, RefreshCw, ArrowLeft, ExternalLink } from 'lucide-react';
import { Amount, usdcDecimalsFor } from '@/onchain-money';
import { buildAddressExplorerUrl } from '@/onchain-facts';
import { FREELANCE_ESCROW_ABI } from '@/contracts/freelanceEscrow';
import MilestoneCard from './MilestoneCard';
import { formatAddress } from '@/utils/errors';

const ARC_TESTNET_ID = 5042002;

interface EscrowDashboardProps {
  escrowAddress: Hex;
  onBack: () => void;
}

const glass = {
  card: {
    background: 'var(--surface-strong)',
    backdropFilter: 'blur(24px) saturate(180%)',
    WebkitBackdropFilter: 'blur(24px) saturate(180%)',
    border: '1px solid var(--border)',
    borderRadius: '24px',
  },
};

export default function EscrowDashboard({ escrowAddress, onBack }: EscrowDashboardProps) {
  const { address } = useAccount();
  const decimals = usdcDecimalsFor(ARC_TESTNET_ID);

  const { data: info, refetch: refetchInfo } = useReadContract({
    address: escrowAddress,
    abi: FREELANCE_ESCROW_ABI,
    functionName: 'getEscrowInfo',
    chainId: ARC_TESTNET_ID,
  });

  const { data: balance, refetch: refetchBalance } = useReadContract({
    address: escrowAddress,
    abi: FREELANCE_ESCROW_ABI,
    functionName: 'getContractBalance',
    chainId: ARC_TESTNET_ID,
  });

  const { data: m0, refetch: refetchM0 } = useReadContract({
    address: escrowAddress,
    abi: FREELANCE_ESCROW_ABI,
    functionName: 'getMilestone',
    args: [0n],
    chainId: ARC_TESTNET_ID,
  });

  const { data: m1, refetch: refetchM1 } = useReadContract({
    address: escrowAddress,
    abi: FREELANCE_ESCROW_ABI,
    functionName: 'getMilestone',
    args: [1n],
    chainId: ARC_TESTNET_ID,
  });

  const { data: m2, refetch: refetchM2 } = useReadContract({
    address: escrowAddress,
    abi: FREELANCE_ESCROW_ABI,
    functionName: 'getMilestone',
    args: [2n],
    chainId: ARC_TESTNET_ID,
  });

  const refetchAll = () => {
    void refetchInfo();
    void refetchBalance();
    void refetchM0();
    void refetchM1();
    void refetchM2();
  };

  const isClient =
    info && address
      ? info[0].toLowerCase() === address.toLowerCase()
      : false;

  const formattedBalance = balance
    ? Amount.fromRaw(balance, decimals).toFixed(2)
    : '—';

  const milestones = [m0, m1, m2];

  return (
    <div className="flex flex-col gap-4">
      {/* Back */}
      <button
        onClick={onBack}
        className="flex items-center gap-1.5 text-sm font-medium transition-opacity hover:opacity-70"
        style={{ color: 'var(--muted)' }}
      >
        <ArrowLeft className="size-4" /> Back
      </button>

      {/* Balance hero */}
      <motion.div
        style={glass.card}
        className="p-5"
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="mb-3 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <div
              className="flex size-5 items-center justify-center rounded-md"
              style={{ background: 'rgba(26,128,71,0.12)' }}
            >
              <Wallet className="size-3" style={{ color: 'var(--success)' }} />
            </div>
            <span className="text-xs font-semibold" style={{ color: 'var(--muted)' }}>
              Contract Balance
            </span>
          </div>
          <button
            onClick={refetchAll}
            className="flex size-7 items-center justify-center rounded-lg transition-opacity hover:opacity-60"
            style={{ background: 'var(--surface-muted)' }}
          >
            <RefreshCw className="size-3.5" style={{ color: 'var(--muted)' }} />
          </button>
        </div>

        <div className="flex items-baseline gap-1.5">
          <span className="display text-4xl font-bold tabular-nums" style={{ color: 'var(--ink)' }}>
            {formattedBalance}
          </span>
          <span className="text-lg font-medium" style={{ color: 'var(--subtle)' }}>
            USDC
          </span>
        </div>

        <div className="mt-3 flex items-center gap-1">
          <a
            href={buildAddressExplorerUrl(ARC_TESTNET_ID, escrowAddress)}
            target="_blank"
            rel="noreferrer"
            className="mono flex items-center gap-1 text-xs transition-opacity hover:opacity-70"
            style={{ color: 'var(--subtle)' }}
          >
            {formatAddress(escrowAddress)} <ExternalLink className="size-3" />
          </a>
        </div>

        {/* Parties */}
        {info && (
          <div className="mt-4 grid grid-cols-2 gap-3">
            <div
              className="rounded-xl px-3 py-2"
              style={{ background: 'var(--surface-muted)' }}
            >
              <div className="mb-0.5 text-xs font-medium" style={{ color: 'var(--subtle)' }}>
                Client {isClient && '(you)'}
              </div>
              <div className="mono text-xs" style={{ color: 'var(--ink)' }}>
                {formatAddress(info[0])}
              </div>
            </div>
            <div
              className="rounded-xl px-3 py-2"
              style={{ background: 'var(--surface-muted)' }}
            >
              <div className="mb-0.5 text-xs font-medium" style={{ color: 'var(--subtle)' }}>
                Freelancer
              </div>
              <div className="mono text-xs" style={{ color: 'var(--ink)' }}>
                {formatAddress(info[1])}
              </div>
            </div>
          </div>
        )}
      </motion.div>

      {/* Milestone cards */}
      <div className="flex flex-col gap-3">
        {milestones.map((m, i) =>
          m ? (
            <MilestoneCard
              key={i}
              index={i}
              amount={m[0]}
              status={m[1]}
              deadline={m[2]}
              escrowAddress={escrowAddress}
              isClient={isClient}
              onAction={refetchAll}
            />
          ) : (
            <div
              key={i}
              className="h-28 animate-pulse rounded-2xl"
              style={{ background: 'var(--surface-muted)' }}
            />
          ),
        )}
      </div>

      {!isClient && (
        <p className="text-center text-xs" style={{ color: 'var(--muted)' }}>
          Only the client can approve, release, or refund milestones.
        </p>
      )}
    </div>
  );
}
