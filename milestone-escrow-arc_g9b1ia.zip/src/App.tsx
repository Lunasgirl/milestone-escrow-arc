import { useState } from 'react';
import { ConnectKitButton } from 'connectkit';
import { type Hex } from 'viem';
import { TokenUSDC } from '@web3icons/react';
import CreateEscrow from '@/components/CreateEscrow';
import EscrowDashboard from '@/components/EscrowDashboard';
import LoadEscrow from '@/components/LoadEscrow';

export default function App() {
  const [escrowAddress, setEscrowAddress] = useState<Hex | null>(null);

  return (
    <div
      className="min-h-dvh"
      style={{ background: 'var(--bg-gradient)' }}
    >
      {/* Header */}
      <header
        className="sticky top-0 z-20 flex items-center justify-between px-4 py-3.5"
        style={{
          background: 'rgba(255,255,255,0.72)',
          backdropFilter: 'blur(24px) saturate(180%)',
          WebkitBackdropFilter: 'blur(24px) saturate(180%)',
          borderBottom: '1px solid var(--border)',
        }}
      >
        <div className="flex items-center gap-2">
          <TokenUSDC variant="branded" size={24} />
          <span className="display text-base font-semibold" style={{ color: 'var(--ink)' }}>
            FreelanceEscrow
          </span>
          <span
            className="rounded-full px-2 py-0.5 text-xs font-semibold"
            style={{ background: 'rgba(18,45,69,0.08)', color: 'var(--muted)' }}
          >
            Arc Testnet
          </span>
        </div>
        <ConnectKitButton />
      </header>

      {/* Main content */}
      <main className="mx-auto max-w-md px-4 py-6">
        {escrowAddress ? (
          <EscrowDashboard
            escrowAddress={escrowAddress}
            onBack={() => setEscrowAddress(null)}
          />
        ) : (
          <div className="flex flex-col gap-4">
            {/* Hero intro */}
            <div className="py-2">
              <h1
                className="display text-2xl font-bold"
                style={{ color: 'var(--ink)', letterSpacing: '-0.03em' }}
              >
                Milestone Escrow
              </h1>
              <p className="mt-1.5 text-sm text-balance" style={{ color: 'var(--muted)' }}>
                Fund freelance work in 3 USDC milestones. Approve, release, or refund each step
                on-chain — no trust required.
              </p>
            </div>

            {/* Create form */}
            <CreateEscrow onCreated={(addr) => setEscrowAddress(addr as Hex)} />

            {/* Divider */}
            <div className="flex items-center gap-3">
              <div className="flex-1" style={{ height: '1px', background: 'var(--border)' }} />
              <span className="text-xs" style={{ color: 'var(--subtle)' }}>
                or
              </span>
              <div className="flex-1" style={{ height: '1px', background: 'var(--border)' }} />
            </div>

            {/* Load existing */}
            <LoadEscrow onLoad={(addr) => setEscrowAddress(addr)} />

            {/* Footer */}
            <p className="text-center text-xs" style={{ color: 'var(--subtle)' }}>
              Powered by USDC on Arc Network · Contracts are non-custodial
            </p>
          </div>
        )}
      </main>
    </div>
  );
}
